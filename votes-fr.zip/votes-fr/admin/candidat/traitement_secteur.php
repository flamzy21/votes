<?php require('../utilisateurs/ma_session.php');
// require('../utilisateurs/mon_role.php');  ?>
<?php  
if (isset($_POST['sub'])) {
	# code...
	echo "Grace";
}
?>
