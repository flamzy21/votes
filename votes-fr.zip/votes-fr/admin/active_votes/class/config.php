<?php
// definition de mes constantes du fichier class;php
define('DBUSER', "root");
define('DBPASS', "");