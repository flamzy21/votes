<?php
$pdo = new PDO("mysql: host=localhost;	dbname=votes",	"root", "");
//echo "connexion :OK";
?>
